
/************** header ************** 
name of the file: pirate.h
name: Ishikaa Kothari
class and homework #: CPSC 223 and pset 3 part 2
date: March 10, 2023 
purpose: defines and mentions all functions and types needed for pirate.c
and defines pirate and skills struct
*/ 

#ifndef __PIRATE_H__
#define __PIRATE_H__

#include <stdlib.h>

// Type/struct of a skills.
typedef struct _skills{
    size_t capacity;
    size_t length;
    char** array;
} skills;
// Type/struct of a pirate.
typedef struct _impl
{
    char* name;
    char* title;
    char* vessel;
    char* port;
    int treasure;
    struct _impl* captain;
    skills* skill_list;
}pirate; 

//creates a pirate and initializes its fields
pirate *pirate_create();

//creates skills and initializes its fields
skills *create();

//returns the index of a skill within skill_list
size_t index_of(skills *skill_list, char* skill);

//expands the skill_list
void expand_if_necessary(skills *skill_list);

//contracts the skill_list if the capacity is too small
void contract_if_necessary(skills *skill_list);

//inserts a skill into skill_list
char *insert(skills *skill_list, char* skill, size_t idx);

//Removes the skill from the list 
//and returns a pointer to it.
char *skill_remove(skills *skill_list, char* skill);

//accesses a skill in skill_list
char *access(skills *skill_list, size_t idx);

//sorts skills in alphabetical order
void sort(skills *skill_list);

//prints the skills with its rating 
void print_skills(skills *skill_list);

//returns the length of skill_list
size_t skill_length(skills *skill_list);

//prints captain information
void print_captain(pirate *p);

//prints a pirate profile
void print_profile(pirate *p);

//frees memory for skills and its array
void destroy(skills *skill_list);

//frees memory for pirate and its fields
void pirate_destroy(pirate *p);

#endif
