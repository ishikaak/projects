/************** header ************** 
name of the file: pirate.c
name: Ishikaa Kothari
class and homework #: CPSC 223 and pset 3 part 2
date: March 10, 2023 
purpose: implements all functions for pirate and 
skill_list and initializes pirate
*/ 

#include "pirate.h"
#include <string.h>
#include <stdio.h>

#define INITIAL_CAPACITY 25
#define RESIZE_RATIO 2

//creates a pirate and initializes its fields
pirate *pirate_create(){
    //basically sets every fields to NULL
    pirate *main_pirate = malloc(sizeof(pirate));
    main_pirate->name = NULL;
    main_pirate->title = NULL;
    main_pirate->vessel = malloc(sizeof(char) * 66);
    strcpy(main_pirate->vessel, "");
    main_pirate->port = NULL;
    main_pirate->treasure = 0;
    return main_pirate;
}

//creates skills and initializes its fields
skills *create(){
    //create memory for skill_list
    skills *lst = malloc(sizeof(skills)); 
    if (lst != NULL){
        lst->capacity = INITIAL_CAPACITY;
        lst->length = 0;
        //create memory for skill_list array
        lst->array = malloc(sizeof(char*) * lst->capacity); 
    }
    //return pointer to skill_list
    return lst;
}

//returns the index of a skill within skill_list
size_t index_of(skills *skill_list, char* skill){
    //looping through skill_list
    for (int i = 0; i < skill_list->length; i++){ 
        //comparing the names of each skill in 
        //the list and the given skill
        if (strcmp(skill_list->array[i], skill) == 0){ 
            return i;
        }
    }
    return skill_list->length; 
}

//expands the skill_list
void expand_if_necessary(skills *skill_list){
    //checks if the capacity is too small compared to length
    if (skill_list->length >= skill_list->capacity){
        //doubles the capacity
        skill_list->capacity = skill_list->capacity * RESIZE_RATIO;
        //reallocates more memory to the skill_list array
        skill_list->array = realloc(skill_list->array, 
        sizeof(void*) * skill_list->capacity); 
        fprintf(stderr, "Expand to %ld\n", skill_list->capacity);
    }
}

//contracts the skill_list if the capacity is too small
void contract_if_necessary(skills *skill_list){
    //checks if capacity is too big compared to length
    if (skill_list->length < skill_list->capacity / (RESIZE_RATIO * 2)
    && skill_list->capacity > INITIAL_CAPACITY){
        //makes sure that the capacity of the array must 
        //never fall below INITIAL_CAPACITY
        if (skill_list->capacity / RESIZE_RATIO < INITIAL_CAPACITY){
            skill_list->capacity = INITIAL_CAPACITY;
        }
        else{
            skill_list->capacity = skill_list->capacity / RESIZE_RATIO;
        }
        //reallocates less memory to a skill_list array
        skill_list->array = realloc(skill_list->array, 
        sizeof(void*) * skill_list->capacity); 
        fprintf(stderr, "Contract to %ld\n", skill_list->capacity);
    }
}

//inserts a skill into skill_list
char *insert(skills *skill_list, char* skill, size_t idx){
    expand_if_necessary(skill_list);
    //looping through skill_list array
    //shifting elements to account for insert
    for (int i = skill_list->length; i > idx; i--){
        skill_list->array[i] = skill_list->array[i-1];
    }
    //inserting 
    skill_list->array[idx] = skill;
    //incrementing length
    skill_list->length++;
    return NULL;
}

//Removes the skill from the list 
//and returns a pointer to it.
char *skill_remove(skills *skill_list, char* skill){
    //gets index of skill
    size_t idx = index_of(skill_list, skill);
    if (idx == skill_list->length){
        return NULL;
    }
    else{
        //shifting elements to account for remove 
        for (int i = idx; i < skill_list->length-1; i++){ 
            skill_list->array[i] = skill_list->array[i+1];
        }
        skill_list->array[idx] = skill;
        //decrementing length
        skill_list->length--;
        contract_if_necessary(skill_list);
        return skill;
    }
}

//accesses a skill in skill_list
char *access(skills *skill_list, size_t idx){
    if (idx >= skill_list->length){
        return NULL;
    }
    else{
        //returns index of skill
        return skill_list->array[idx];
    }
}

//sorts skills in alphabetical order through insertion sort
//check sort commenting in pirate_list.c in part 1
void sort(skills *skill_list){
    int j;
    for (int i = 0; i < skill_list->length; i++){
        j = i;
        char* temp_skill = malloc(sizeof(char) * 66); 
        while (j > 0 && strcmp(skill_list->array[j-1], 
        skill_list->array[j]) > 0){
            temp_skill = skill_list->array[j];
            skill_list->array[j] = skill_list->array[j-1];
            skill_list->array[j-1] = temp_skill;
            j = j-1; 
        }

    }
}

//prints the skills with its rating 
void print_skills(skills *skill_list){
    int counter = 0;
    //looping through skill_list
    for (int i = 0; i < skill_list->length; i++){
        if (i == 0){
            printf("    Skills: %s *", skill_list->array[i]);
        }
        //if same skill, increment counter
        if (i > 0 && (strcmp(skill_list->array[i-1], 
        skill_list->array[i]) == 0)){
            counter++;
        }
        //if different skill, print the *s for previous skill
        if (i > 0 && !(strcmp(skill_list->array[i-1], 
        skill_list->array[i]) == 0)){
            for (int j = 0; j < counter; j++){
                printf("*");
            }
            //set counter back to 0
            counter = 0;
            printf("\n            %s *", skill_list->array[i]);
        }
        //print all *s for last skill
        if (i == (skill_list->length - 1)){
            for (int j = 0; j < counter; j++){
                printf("*");
            }
            printf("\n");
        }
    }
}

//returns the length of skill_list
size_t skill_length(skills *skill_list){
    return skill_list->length;
}

//prints captain information
void print_captain(pirate *p){
    if (p->captain == NULL){ 
        printf("    Captain: (None)\n");
    }
    else{
        printf("    Captain: %s\n", p->captain->name); 
        if (p->captain->title == NULL){
            printf("        Captain's Title: (None)\n");
        }
        else{
            printf("        Captain's Title: %s\n", p->captain->title);
        }
        if (p->captain->port == NULL){
            printf("        Captain's Favorite Port of Call: (None)\n");
        }
        else{
            printf("        Captain's Favorite Port of Call: %s\n", p->captain->port);
        }
    }
}

//prints a pirate profile
void print_profile(pirate *p){
    if (p->name == NULL){ 
        printf("Pirate: (None)\n");
    }
    else{
        printf("Pirate: %s\n", p->name);
    }
    if (p->title == NULL){
        printf("    Title: (None)\n");
    }
    else{
        printf("    Title: %s\n", p->title);
    }
    print_captain(p);
    if (strcmp(p->vessel, "") == 0){
        printf("    Vessel: (None)\n");
    }
    else{
        printf("    Vessel: %s\n", p->vessel);
    }
    if (p->treasure == 0){ 
        printf("    Treasure: (None)\n");
    }
    else{
        printf("    Treasure: %d\n", p->treasure);
    }
    if (p->port == NULL){
        printf("    Favorite Port of Call: (None)\n");
    }
    else{
        printf("    Favorite Port of Call: %s\n", p->port);
    }
    if (skill_length(p->skill_list) == 0){
        printf("    Skills: (None)\n");
    }
    else{
        sort(p->skill_list);
        print_skills(p->skill_list);
    }
    printf("\n");
}

//frees memory for skills and its array
void destroy(skills *skill_list){
    free(skill_list->array);
    free(skill_list); 
}

//frees memory for pirate and its fields
void pirate_destroy(pirate *p){
    free(p->name); 
    free(p->title); 
    free(p->vessel); 
    free(p->port); 
    //freeing skills in skill_list
    for (int j = 0; j < p->skill_list->length; j++){
        free(p->skill_list->array[j]);
    }
    destroy(p->skill_list);
    free(p);
}
