
/************** header ************** 
name of the file: hookbook.c
name: Ishikaa Kothari
class and homework #: CPSC 223 and pset 3 Ahoy Matey! part 2
date: March 10, 2023 
purpose: this driver file reads in the pirate profiles, which the program
puts into an array list called pirate_list, and
the captain/pirate match pairs. Then, it prints out information about the 
pirate profiles and associated captain information
based on the inputted sort type. There are three sort types: by pirate name alphabetically,
vessel name alphabetically, and their number of treasures in decreasing order.
*/ 

#include <stdio.h>
#include <string.h>
#include "pirate_list.h"

//one extra number to account for \n
#define NAMELENGTH 66 

int main(int argc, char* argv[]){
    if (argc >= 4){ //checks if the commands are 
        const char *filename1 = argv[1];
        const char *filename2 = argv[2];
        char* sort_type = argv[3];
        // Checks if file exists and opens them
        FILE *pirate_profiles = fopen(filename1, "r");
        FILE *pairs = fopen(filename2, "r");
		if (pirate_profiles == NULL || pairs == NULL) {
            fprintf(stderr, "Invalid filename: %s\n", filename1); 
			return 1;
		}
		if (pirate_profiles == NULL && pairs == NULL) {
            fprintf(stderr, "Invalid filename: %s\n", filename2);
			return 1;
		}
        //checks if the third argument is correct
        if (!((strcmp(sort_type, "-n") == 0)||  
        (strcmp(sort_type, "-v") == 0) || (strcmp(sort_type, "-t") == 0))){
            fprintf(stderr, "Invalid argument: %s\n", sort_type); 
            return 1;
        }

        pirate_list *names_list = list_create();
        pirate *new_pirate = NULL;
        //reads in information from the pirate profiles file and 
        //puts it in the correct field
        char* label = calloc( NAMELENGTH,sizeof(char));
        char* value = calloc( NAMELENGTH,sizeof(char));
		while ((fscanf(pirate_profiles, "%[^:]:", label) == 1) && 
        (fscanf(pirate_profiles, "%[^\n]\n", value) == 1)) {
            if (strcmp(label, "name") == 0){
                //inserting pirate into pirate_list
                if (new_pirate != NULL){
                    pirate* temp = list_insert(names_list, new_pirate, list_length(names_list));
                    if (temp!= NULL){
                        pirate_destroy(new_pirate);
                    }
                }
                new_pirate = pirate_create(); 
                //allocating memory for name fields and 
                //copying the value form the file into it 
                //I do the same steps for all the other fields
                new_pirate->name = malloc(sizeof(char) * NAMELENGTH);
                strcpy(new_pirate->name, value);
                new_pirate->skill_list=create();
            }
            if (strcmp(label, "title") == 0){
                new_pirate->title = malloc(sizeof(char) * NAMELENGTH);
                strcpy(new_pirate->title, value);
            }
            if (strcmp(label, "vessel") == 0){
                strcpy(new_pirate->vessel, value);
            }
            if (strcmp(label, "port") == 0){
                new_pirate->port = malloc(sizeof(char) * NAMELENGTH);
                strcpy(new_pirate->port, value);
            }
            if (strcmp(label, "treasure") == 0){
                new_pirate->treasure = atoi(value);
            }
            if (strcmp(label, "skill") == 0){
                char* pirate_skill = malloc(sizeof(char) * NAMELENGTH);
                strcpy(pirate_skill, value);
                insert(new_pirate->skill_list, pirate_skill, 
                skill_length(new_pirate->skill_list));
            }
        }
        //inserts the last pirate in pirate_list
        if (new_pirate != NULL){
            pirate* temp = list_insert(names_list, new_pirate, 
            list_length(names_list));
            if (temp!= NULL){
                pirate_destroy(new_pirate);
            }
        }
        //reads in information from the captain/pirate pairs file and 
        //puts it in the correct field
        while ((fscanf(pairs, "%[^/]/", label) == 1) && 
        (fscanf(pairs, "%[^\n]\n", value) == 1)) {
            //connects the captain to the correct pirate
            pirate *captain_pointer;
            pirate *pirate_pointer;
            //finds the correct captain pointer
            for (int j = 0; j < list_length(names_list); j++){
                if (strcmp(value, list_access(names_list, j)->name) == 0){
                    captain_pointer = list_access(names_list, j);
                }
            //finds the correct pirate pointer
                if (strcmp(label, list_access(names_list, j)->name) == 0){
                    pirate_pointer = list_access(names_list, j);
                }
            }
            pirate_pointer->captain = captain_pointer;
            // printf("%s\n", pirate_pointer->name);
            // printf("%s\n", pirate_pointer->captain->name);
        }
        
        list_sort(names_list, sort_type); //sorting pirate_list

        //prints out all the information from the pirate fields 
        //in the correct arrangement
        for (int i = 0; i < list_length(names_list); i++){
            print_profile(list_access(names_list, i));
        }
        
        //frees the pirate fields, pirate, pirate_list array, and pirate_list
        for (int i = 0; i < list_length(names_list); i++){
            pirate_destroy(list_access(names_list, i));
        }
        list_destroy(names_list);
        //closes the files
        fclose(pirate_profiles);
        fclose(pairs);
    }
    else{
        fprintf(stderr, "Invalid arguments\n");
        return 1;
    }
    return 0;    
} 
