
//************************************************************************
// Class: GuitarHero
// Dependencies: RingBuffer GuitarString StdAudio DrawingPanel 
//
// Description  :  GuitarHero 
//  
// This program uses the math from GuitarString and methods from RingBuffer
// and GuitarString to play strings that players have typed on the keyboard, 
// stimulating and creating a guitar. 
// NOTE: The code indentations get messed up on gradescope but the structure 
// seems fine when downloaded and in visual code. 
//************************************************************************
import java.awt.*;

public class GuitarHero {
	// set up panel and graphics objects
	private static final int WIDTH = 768;
	private static final int HEIGHT = 256;
	private static DrawingPanel panel = new DrawingPanel(WIDTH, HEIGHT);
	private static Graphics2D g = panel.getGraphics();

	private static final int DRAW_SAMPLE_RATE = 20; // draw at a rate of 20/sec
	private static final int AUDIO_PER_DRAW = StdAudio.SAMPLE_RATE / DRAW_SAMPLE_RATE;

	private static final int PLAY_TIME = 10; // target 60 seconds display window
	private static final int X_RANGE = DRAW_SAMPLE_RATE * PLAY_TIME;

    private static GuitarString guitarStrings[ ];
    private static double sample;

	// general scaling method
	public static double scale(double oldValue, double oldMin, double oldMax, double newMin, double newMax) {
		return (oldValue - oldMin) / (oldMax - oldMin) * (newMax - newMin) + newMin;
	}

	// helpers for scaling to window
	public static int scaleToHeight(double oldValue) {
		return (int) (scale(oldValue, -1, 1, 0, HEIGHT));
	}

	public static int scaleToWidth(double oldValue) {
		return (int) (scale(oldValue, 0, X_RANGE, 0, WIDTH));
	}

	public static void main(String[] args) {
    	//need an array with all freqiences to create array with strings 
    	String keyboard = "q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' "; //creates keyboard string
    	guitarStrings = new GuitarString[keyboard.length()]; //creates an array of GuitarStrings
    	for (int i = 0; i < keyboard.length(); i++){
        	//adds the calculated frequency to the appropriate GuitarString
        	guitarStrings[i] = new GuitarString(440 * Math.pow(2, (i - 24)/12.0)); 
        }

		// Set up keyboard listener (similar to mouse listener from last pset)
		panel.onKeyDown((key) -> {
			if (keyboard.indexOf(key) > -1){ //checks if the value pressed is in the keyboard
				guitarStrings[keyboard.indexOf(key)].pluck(); //plucks the appropriate GuitarString
        	}
		});

		// fence post
		double xprev = 0, yprev = 0;

		while (true) {
			// compute the superposition of the samples for duration
            sample = 0; //initializing sample
            for (int i = 0; i < keyboard.length(); i++){
            	sample += guitarStrings[i].sample(); //adds all the string samples
            }
			// send the result to standard audio
			StdAudio.play(sample);

			// advance the simulation of each guitar string by one step
            for (int i = 0; i < keyboard.length(); i++){
                guitarStrings[i].tic();
            }

			// Decide if we need to draw.
			// Audio sample rate is StdAudio.SAMPLE_RATE per second
			// Draw sample rate is DRAW_SAMPLE_RATE
			// Hence, we draw every StdAudio.SAMPLE_RATE / DRAW_SAMPLE_RATE
			if (guitarStrings[4].time() % AUDIO_PER_DRAW == 0) {
				g.setColor(Color.RED);
				g.drawLine(scaleToWidth(xprev),
						scaleToHeight(yprev),
						scaleToWidth(xprev + 1),
						scaleToHeight(sample));
				xprev++;
				yprev = sample;
				// check if wrapped around
				if (xprev > X_RANGE) {
					xprev = 0;
					// clear the image
					g.setColor(Color.WHITE);
					g.fillRect(0, 0, WIDTH, HEIGHT);
				}
			} // end of if

		} // end of while

	} // end of main

}
// end of class

