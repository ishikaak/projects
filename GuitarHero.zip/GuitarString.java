//************************************************************************
// Class: GuitarString
// Dependencies: RingBuffer 
//
// Description  :  GuitarString 
//  
// This program creates objects to model a vibrating guitar string.
// It also implements the Karplus-Strong algorithm and creates methods like
// pluck() and tic() that GuitarHero uses. This program builds a tool that 
// is need to make a guitar.
//
//************************************************************************

import java.util.Random;

public class GuitarString {

    private RingBuffer          buffer; // ring buffer
    private static final double DECAY = 0.996;
    private int numTics;

    // create a guitar string of the given frequency
    public GuitarString(double frequency) {
        numTics = 0; //initializing numTics

        int N = (int) Math.round(StdAudio.SAMPLE_RATE/frequency);
        buffer = new RingBuffer(N); //creates a RingBuffer of the desired capacity N
        //initializes buffer to represent a guitar string at rest by enqueueing N number of zeros
        for (int i = 0; i < N; i++){ 
            buffer.enqueue(0);
        }
    }

    // create a guitar string with size & initial values given by the array
    public GuitarString(double[] init) {
        numTics = 0; //initializing numTics

        buffer = new RingBuffer(init.length); //creates a RingBuffer of capacity equal to the size of the array
        //initializes the contents of the buffer to the values in the init array
        for (int i = 0; i < init.length; i++){
            buffer.enqueue(init[i]);
        } 
    }

    // pluck the guitar string by replacing the buffer with white noise
    public void pluck() {
        double randomValue; 
        //replaces all of the values from the buffer with randomValue or white noise
        for (int i = 0; i < buffer.size(); i++){ 
            randomValue = Math.random() - 0.5; //finds a random value between -0.5 and 0.5
            buffer.dequeue();
            buffer.enqueue(randomValue);
        }
    }

    // advance the simulation one time step
    public void tic() {
        // the dequeue in the next line deletes the sample at the front of the ring buffer 
        double average = DECAY * 1/2 * (buffer.dequeue() + buffer.peek());
        //adds to the end of the ring buffer the average of the 
        //first two samples, multiplied by the energy decay factor
        buffer.enqueue(average); 
        numTics++; //increments the number of times tic was called
    }

    // return the current sample
    public double sample() {
        return buffer.peek(); //returns the value of the item at the front of the ring buffer
    }

    // return number of times tic was called
    public int time() {
        return numTics; 
    }

    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        double[] samples = { .2, .4, .5, .3, -.2, .4, .3, .0, -.1, -.3 };  
        GuitarString testString = new GuitarString(samples);
        for (int i = 0; i < N; i++) {
            int t = testString.time();
            double sample = testString.sample();
            System.out.printf("%6d %8.4f\n", t, sample);
            testString.tic();
        }
    }

}
