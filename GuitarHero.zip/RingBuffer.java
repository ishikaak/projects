//************************************************************************
// Description  :  RingBuffer
//  
//  This program creates an object to model the ring buffer. It also builds 
//  methods, like enqueue(double x) and dequeue(), which we use in other classes like GuitarString.
//  This program builds a tool that is need to make a guitar string.
//
//************************************************************************

public class RingBuffer {
    private double[] rb;          // items in the buffer
    private int first;            // index for the next dequeue or peek
    private int last;             // index for the next enqueue
    private int size;             // number of items in the buffer

    // create an empty buffer, with given max capacity
    public RingBuffer(int capacity) {
        first = 0; //initializing first
        last = 0; //initializing last
        size = 0; //initializing size

        rb = new double[capacity]; //initializing rb 
    }

    // return number of items currently in the buffer
    public int size() {
        return size;
    }

    // checks if the buffer is empty by checking if size equals zero
    public boolean isEmpty() {
        if (size() == 0){
            return true;
        }
        else{
            return false;
        }
    }

    // checks if the buffer is full by checking if size equals array capacity
    public boolean isFull() {
        if (size() == rb.length){
            return true;
        }
        else{
            return false;
        }
    }

    // add item x to the end
    public void enqueue(double x) {
        if (isFull()) {
            throw new RuntimeException("Ring buffer overflow"); //if the buffer is full, thows an error
        }
        rb[last] = x; //adds x to the end
        last = (last + 1) % rb.length; //to wrap back around
        size++; //increments size
    }

    // delete and return item from the front
    public double dequeue() {
        if (isEmpty()) {
            throw new RuntimeException("Ring buffer underflow"); //if the buffer is empty, thows an error
        }
        double ret = rb[first]; 
        first = (first + 1) % rb.length; //to wrap back around 
        size--; //decrements size
        return ret;
    }

    // return (but do not delete) item from the front
    public double peek() {
        if (isEmpty()) {
            throw new RuntimeException("Ring buffer underflow"); //if the buffer is empty, thows an error
        }
        return rb[first]; //returns item from the front
    }

    // a simple test of the constructor and methods in RingBuffer
    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        RingBuffer buffer = new RingBuffer(N);
        for (int i = 1; i <= N; i++) {
            buffer.enqueue(i);
        }
        double t = buffer.dequeue();
        buffer.enqueue(t);
        System.out.println("Size after wrap-around is " + buffer.size());
        while (buffer.size() >= 2) {
            double x = buffer.dequeue();
            double y = buffer.dequeue();
            buffer.enqueue(x + y);
        }
        System.out.println(buffer.peek());
    }

}
