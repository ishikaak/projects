//*******************************************************************
//      Dependency: WordCounter.java
//      This program uses the ArrayList of the number of times a certain
//      word is mentioned in a file to create a word cloud. The
//      more prevalent the word is or the higher the number is,
//      the bigger the word is in the cloud. This program ensures
//      that no words intersect. 
//
//*******************************************************************
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Map.Entry;
import java.util.Random;
import java.util.ArrayList;

public class WordCloud {

    // width and height of the screen
	public static final int WIDTH = 600;
	public static final int HEIGHT = 600;

	// set up panel. no need for double buffering in this case
	public static DrawingPanel panel = new DrawingPanel(WIDTH, HEIGHT);
	public static Graphics2D g = panel.getGraphics();

    public static final int FONT_MIN = 30; 
    public static final int FONT_MAX = 150;
    public static final int RGB_UPPERBOUND = 256;
    public static final int INCREMENT = 5;
    public static double fontSize;
    public static Word[] words;

    public static void main(String[] args) { 

        String filename = args[0];
        int num = Integer.parseInt(args[1]);

        WordCounter wordCounter = new WordCounter(filename); //creates an object of class WordCounter
        //creates an ArrayList of the word frequencies ordered from largest number to smallest
        ArrayList<Entry<String, Integer>> values = wordCounter.getTopN(num); 
        int maxValue = values.get(0).getValue(); //gets the largest value in the ArrayList
        int minValue = values.get(num - 1).getValue(); //gets the smallest value in the ArrayList
        words = new Word[num];
        for (int i = 0; i < num; i++){
            // scales the values to the font size range
            fontSize = scale(values.get(i).getValue(), minValue, maxValue, FONT_MIN, FONT_MAX);
            // sets up words array with new Word objects constructed from the word text and scaled size
            words[i] = new Word(values.get(i).getKey(), fontSize, WIDTH/2, HEIGHT/2);
        }        
        drawAllWords();
    }


	// general scaling method
	private static double scale(double oldValue, double oldMin, double oldMax, double newMin, double newMax) {
		return (oldValue - oldMin) / (oldMax - oldMin) * (newMax - newMin) + newMin;
	}

    //draws the words
    public static void drawAllWords() {

        // start by drawing the largest word
        words[0].drawWord(g, randomColor());

        // looping through the remaining words from largest to smallest
        for (int i = 1; i < words.length; i++){
            spiralShift(i, INCREMENT); // uses spiralShift to move each word to a new location
            words[i].drawWord(g, randomColor()); // then draw the word

        }
    }

    //returns a random color by getting random values for R, G, and B;
    private static Color randomColor() {
		Random rand = new Random();
		int randR = rand.nextInt(RGB_UPPERBOUND);
        int randG = rand.nextInt(RGB_UPPERBOUND);
        int randB = rand.nextInt(RGB_UPPERBOUND);
        return new Color(randR, randG, randB); 
    }

    public static void spiralShift(int i, int increment) {
        int x = 0, y = 0, dx = increment, dy = 0;
        //keeps on looping if the current word intersects with any previously placed word 
        while (testIntersection(i)){
            //shifts the position of a Word dx pixels in the x-axis and dy pixels in the y-axis
            words[i].shiftPosition(dx, dy); 
            x = x + dx; //updates x
            y = y + dy; //updates y
            // determine if you have reached a bend in the spiral and adjust dx/dy accordingly
            if (x >= 0){
                if (Math.abs(x) <= y){ //right shift
                    dx = increment;
                    dy = 0;
                }
                else if (x > Math.abs(y)) { //up shift 
                    dx = 0;
                    dy = -increment;
                }
                else { //left shift
                    dx = -increment;
                    dy = 0;
                }
            }
            else {
                if (x > y) { //left shift 
                    dx = -increment;
                    dy = 0;
                }
                else if (Math.abs(x) > y) { //down shift 
                    dx = 0;
                    dy = increment;
                }
                else { //right shift
                    dx = increment;
                    dy = 0;
                }
            }
        }
    }

    // checks if the current word intersects with any of the *previously* placed words
    public static boolean testIntersection(int i) {
        for (int j = i - 1; j >= 0; j--) {
            if (words[i].intersects(words[j])) {
                return true;
            }
        }
        return false;
    }
}
