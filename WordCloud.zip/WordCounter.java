//*******************************************************************
//      This program loads text files, counts the times a word that 
//      is not in stopwords.txt is mentioned in the file, and 
//      creates an ArrayList of these numbers. This program 
//      also orders the values from most prevalent to least prevalent
//      in the file.
//
//*******************************************************************
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class WordCounter {
    final static String stopwordsFile = "stopwords.txt";

    ArrayList<String> documentWords;
    HashSet<String> stopWords;

    public WordCounter(String filename) {
        loadDocument(filename);
        loadStopWords(stopwordsFile);
    }

    // loads the document's words into the ArrayList instance variable
    private void loadDocument(String filename) {
        documentWords = new ArrayList<String>(); //initializes the arrayList
        try {
            File file = new File(filename);  //uploads files
            Scanner scan = new Scanner(file); //scans files
            try{ 
                while (scan.hasNext()) { //keeps looping until there are no more words
                    String word = scan.next(); //scans each words from the file 
                    word = word.replaceAll("[^a-zA-Z]", ""); // removes punctuation from a string
                    if (word != ""){
                        documentWords.add(word.toLowerCase()); //put a lowercase version of each scanned word in the ArrayList
                    }
                }
                scan.close(); //closes scanner
            } catch (Exception e) { //returns an error if there are no (new) words can be found in the document
                System.out.println("Error: No document words found."); 
            }
        } catch (FileNotFoundException e) { //returns an error if words.txt is not found
            System.out.println("Error: Unable to read file.");
        }
    }

    // reads in the stopwords and adds into stopWords HashSet 
    private void loadStopWords(String filename) {
        stopWords = new HashSet<String>(); //initializes the hashSet
        try {
            File file = new File(filename);  //uploads stopwords.txt
            Scanner scan = new Scanner(file); //scans file
            try{
                while (scan.hasNextLine()) { //keeps on looping until there are no more lines
                    String stopWord = scan.nextLine(); //scans in each line of the file
                    stopWords.add(stopWord.toLowerCase()); //adds a lowercase version of each word into the hashSet
                }
                scan.close(); //closes the scanner
            } catch (Exception e) { //returns an error if there are no (new) words can be found in the document
                System.out.println("Error: No stop words found."); 
            }
        } catch (FileNotFoundException e) { //returns an error if words.txt is not found
            System.out.println("Error: Unable to read file.");
        }
    }

    //creates a HashMap of each word with its frequency number
    public HashMap<String, Integer> wordFrequency() {
        HashMap<String, Integer> wordCountHashMap = new HashMap<String, Integer>();
        for (String word : documentWords) { // loops through each string element in the ArrayList
            if (stopWords.contains(word) == false){ // checks if each document word is in the stopwords 
                if (wordCountHashMap.containsKey(word) == false){ //checks if the word is in the HashMap
                    wordCountHashMap.put(word, 1); //if it is not in the HashMap, adds the word in with value = 1
                }
                else { //if the word is already in the HashMap, it increases the value of the word by 1.
                    wordCountHashMap.put(word, wordCountHashMap.get(word) + 1); //counting occurances
                }
            }
        } 
        return wordCountHashMap; // returns the HashMap
    }

    // Finds and returns the entry with the largest value
    private Entry<String, Integer> getMaxEntry(HashMap<String, Integer> counts) {
        Entry<String, Integer> maxKey = counts.entrySet().iterator().next(); //creates an arbitrary entry from the HashMap
        for (Entry<String, Integer> key : counts.entrySet()) { //loops through all entries in the set
            if (maxKey.getValue() < key.getValue()){ //finds the max value
                maxKey = key;
            }
        }
        return maxKey; // counts.entrySet().iterator().next();
    }

    //creates and returns an ArrayList of the words frequencies from the largest number to the smallest
    public ArrayList<Entry<String, Integer>> getTopN(int n) {
        HashMap<String, Integer> counts = wordFrequency(); //creates HashMap
        ArrayList<Entry<String, Integer>> maxCounts = new ArrayList<Entry<String, Integer>>(); //creates ArrayList
        for (int i = 0; i < n; i++){ //loops n times
            maxCounts.add(getMaxEntry(counts)); //adds the largest value to the ArrayList
            counts.remove(getMaxEntry(counts).getKey()); //removes the largest value from the counts hashmap
        }
        return maxCounts;// return the ArrayList
    }

}
