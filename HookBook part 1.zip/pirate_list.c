/************** header ************** 
name of the file: pirate_list.c
name: Ishikaa Kothari
class and homework #: CPSC 223 and pset 3 part 1
date: March 10, 2023 
purpose: implements all functions for pirate_list
*/ 

#include "pirate_list.h"
#include <string.h>
#include <stdio.h>

#define INITIAL_CAPACITY 25
#define RESIZE_RATIO 2
// Type (struct) of list of pirates
struct implementation {
    size_t capacity;
    size_t length;
    pirate** array;
};

//Allocates memory for a new pirate_list 
//and returns a pointer to it.
pirate_list *list_create(){
    pirate_list *lst = malloc(sizeof(pirate_list)); 
    if (lst != NULL){
        lst->capacity = INITIAL_CAPACITY;
        lst->length = 0;
        //creating memory for pirate_list array
        lst->array = malloc(sizeof(pirate*) * lst->capacity); 
    }
    return lst;
}

//returns the index of the pirate within pirate_list
size_t list_index_of(pirate_list *pirates, pirate *p){
    //looping through pirate_list
    for (int i = 0; i < pirates->length; i++){ 
        //comparing the names of each pirate in 
        //the list and the given pirate
        if (strcmp(pirates->array[i]->name, p->name) == 0){ 
            return i;
        }
    }
    return pirates->length; 
}

//expands the pirate_list
void list_expand_if_necessary(pirate_list* pirates){
    //checks if the capacity is too small compared to length
    if (pirates->length >= pirates->capacity){
        //doubles the capacity
        pirates->capacity = pirates->capacity * RESIZE_RATIO; 
        //reallocates more memory to the pirate_list
        pirates->array = realloc(pirates->array, 
        sizeof(pirate*) * pirates->capacity); 
        fprintf(stderr, "Expand to %ld\n", pirates->capacity);
    }
}

//contracts the pirate_list if the capacity is too small
void list_contract_if_necessary(pirate_list* pirates){
    //checks if capacity is too big compared to length
    if (pirates->length < pirates->capacity / (RESIZE_RATIO * 2) 
    && pirates->capacity > INITIAL_CAPACITY){
        //makes sure that the capacity of the array must 
        //never fall below INITIAL_CAPACITY
        if (pirates->capacity / RESIZE_RATIO < INITIAL_CAPACITY){
            pirates->capacity = INITIAL_CAPACITY;
        }
        else{
            pirates->capacity = pirates->capacity / RESIZE_RATIO;
        }
        //reallocates less memory to a pirate_list
        pirates->array = realloc(pirates->array, sizeof(pirate*) * pirates->capacity); 
        fprintf(stderr, "Contract to %ld\n", pirates->capacity);
    }
}


//Only if there is no pirate in the list with the same name as p,
// it inserts pirate p into the list at index idx
pirate *list_insert(pirate_list *pirates, pirate *p, size_t idx){
    //looping through a pirate_list
    for (int i = 0; i < pirates->length; i++){ 
        //checks for duplicate pirate
        if (strcmp(pirates->array[i]->name, p->name) == 0){
            return p;
        }
    }
    list_expand_if_necessary(pirates);
    //inserting the pirate in pirate_list
    for (int i = pirates->length; i > idx; i--){
        pirates->array[i] = pirates->array[i-1];
    }
    pirates->array[idx] = p;
    //incrementing pirate_list length
    pirates->length++; 
    return NULL;
}


//Removes the pirate from the list with the same name as p 
//and returns a pointer to it.
pirate *list_remove(pirate_list *pirates, pirate *p){
    //gets index of pirate p
    size_t idx = list_index_of(pirates, p); 
    if (idx == pirates->length){
        return NULL;
    }
    else{
        //removing the pirate from the pirate_list
        for (int i = idx; i < pirates->length-1; i++){ 
            pirates->array[i] = pirates->array[i+1];
        }
        pirates->length--; //decrementing length
        list_contract_if_necessary(pirates);
        return p; //returning pointer to p
    }
}

//accesses pirate in pirate_list
pirate *list_access(pirate_list *pirates, size_t idx){
    if (idx >= pirates->length){
        return NULL;
    }
    else{
        //returns index of pirate
        return pirates->array[idx]; 
    }
}


//Sorts the list of pirates in alphabetical order 
//by name through insertion sort
void list_sort(pirate_list *pirates){
    int j;
    //looping through the pirate_list
    for (int i = 0; i < pirates->length; i++){ 
        j = i;
        //creating temporary pirate 
        pirate *temp_pirate = malloc(sizeof(pirate*));
        while (j > 0 && strcmp(pirates->array[j-1]->name, 
        pirates->array[j]->name) > 0){
            //swaping two pirates to put them in correct order
            temp_pirate = pirates->array[j];
            pirates->array[j] = pirates->array[j-1];
            pirates->array[j-1] = temp_pirate;
            j = j-1; //changing the element you are comparing with i
        }
    }
}


//Returns the number of pirates in the list.
size_t list_length(pirate_list *pirates){
    return pirates->length;
}

//freeing memory pirate_list array and the pirate_list
void list_destroy(pirate_list *pirates){
    free(pirates->array);
    free(pirates); 
}


