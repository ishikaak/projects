/************** header ************** 
name of the file: pirate.c
name: Ishikaa Kothari
class and homework #: CPSC 223 and pset 3 part 1
date: March 10, 2023 
purpose: defines and creates pirate struct
*/ 

#ifndef __PIRATE_H__
#define __PIRATE_H__

// Type/struct of a pirate.
typedef struct _impl
{
    char* name;
}pirate; 

#endif
