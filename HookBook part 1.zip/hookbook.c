/************** header ************** 
name of the file: hookbook.c
name: Ishikaa Kothari
class and homework #: CPSC 223 and pset 3 part 1
date: March 10, 2023 
purpose: this driver file reads the file lines into 
an array list called pirate_list and uses the functions from pirate_list.c 
to print out an alphabetically sorted pirate_list
*/ 

#include <stdio.h>
#include <string.h>
#include "pirate_list.h"

#define NAMELENGTH 66

int main(int argc, char* argv[]){
    //checks if the commands are greater than or equal to 2
    if (argc >= 2){ 
        const char *filename = argv[1];

        // Checks if file exists
        FILE *fp = fopen(filename, "r");
		if (fp == NULL) {
			return 1;
		}
        //creates a new pirate_list
        pirate_list *names_list = list_create(); 
        //creates a new pirate
        pirate *new_pirate = malloc(sizeof(pirate));
        //allocates memory for pirate name
        new_pirate->name = malloc(sizeof(char) * NAMELENGTH);
        char buffer[NAMELENGTH];
        //reading in each line of the file
		while (fgets(buffer, NAMELENGTH, fp) != NULL) {
            if (buffer[strlen(buffer) -1] == '\n'){
                buffer[strlen(buffer) -1] = '\0';
            }
            //copying the string read into buffer to pirate name
            strcpy(new_pirate->name, buffer);

            //inserting the pirate into pirate_list
            if (new_pirate != NULL){
                pirate* temp = list_insert(names_list, new_pirate, list_length(names_list)); 
                if (temp!=NULL){ //if duplicate pirate, destroy it
                    free(new_pirate->name); 
                    free(new_pirate);
                }
            }

            //creating new memory for a pirate and its name
            new_pirate = malloc(sizeof(pirate)); 
            new_pirate->name = malloc(sizeof(char) * NAMELENGTH);
        }

        list_sort(names_list); //sorting pirate_list
        //printing the sorted pirate_list names
        for (int i = 0; i < list_length(names_list); i++){
            printf("%s\n", list_access(names_list, i)->name); 
        }
        
        //freeing each pirate and its name
        while (list_length(names_list) > 0){
            pirate* pointer = list_remove(names_list, 
            list_access(names_list, 0));
            free(pointer->name);
            free(pointer);
        }
        list_destroy(names_list); //destroying pirate_list
        fclose(fp); //closing file
    }
    else{
        return 1;
    }
    return 0;    
} 
