//*******************************************************************
//      This program creates the Wheel of Words game.
//
//*******************************************************************
import java.util.Scanner;

public class WheelOfWords {
   
   // the secret word
   static String secretWord;

   // the word with guessed letters revealed
   static char[] displayWord;
   // remaining number of chances
   static int remainingChances; 

   // remaining number of unrevealed letters, i.e., the number of '-'s
   static int remainingLetters;

   // keep track of when a game is completed
   static boolean finished;

   // initialize a game
   public static void initialize(int totalChances) { 
      // Pick a secret word
      secretWord = RandomWords.pickAWord().toUpperCase(); 
      System.out.println(secretWord);
      //initialization of the global variables
      remainingChances = totalChances; 
      displayWord = new char[secretWord.length()];
      remainingLetters = secretWord.length();
      finished = false;
   }

   public static void play(Scanner scan) {
      System.out.println("Welcome to Wheel of Words!");
      while (remainingChances != 0 && !finished) {
         displayCurrentStatus(); 
         getUserInput(scan);
      }  //checks if player still has chances to make character guesses

      if (remainingChances == 0 && !finished)
          getFinalGuess(scan); //since the player has no chances, they must make their final guess

   }

   // initialize an array arr with ch
   public static void initCharArray(char[] arr, char ch) { 
      for (int i = 0; i < arr.length; i++) {
         arr[i] = ch; //adds characters to each index in an array
      }
   }

   // show the current progress of the displayWord
   public static void displayCurrentStatus() {  
      System.out.print("The word now looks like this: "); //defines the displayWord array
      if (remainingChances == 8){
         initCharArray(displayWord, '-'); //creates the initial blank line of secretWord length
         System.out.print(displayWord);
         System.out.print("\nYou can buy " + remainingChances + " more letters.");
      }
      else{
         for (int i = 0; i < displayWord.length; i++){ 
            System.out.print(displayWord[i]); //prints displayWord index by index
         }
         if (remainingChances == 1){
            System.out.print("\nYou can only buy " + remainingChances + " more letter!");
         }
         else{
            System.out.print("\nYou can buy " + remainingChances + " more letters.");
         }
      }
   }

   // take user's input and either buyLetter or makeGuess
   public static void getUserInput(Scanner scan) {
      System.out.print("\nBuy a letter or make a final guess: ");
      String response = scan.nextLine();
      response = response.toUpperCase();

      if (response.length() == 1 && response.charAt(0) >='A' && response.charAt(0) <='Z') { //if the player makes a character guess 
         buyLetter(response.charAt(0));
         remainingChances--; //decreases the number of chances by one every time the player makes character guesses
      }
      else { //if the player makes a string guess
         makeGuess(response);
      }
   }

   // user gave a letter, so update current status
   private static void buyLetter(char userChar) { 
      for (int index = 0; index < secretWord.length(); index++){ //loops through all the characters of secretWord
         if (secretWord.charAt(index) == userChar){ //checks if a character of secretWord matches the inputed character
            displayWord[index] = userChar; //puts the matching character in displayWord in the correct position
            remainingLetters--; //decreases the remainingLetters by one
         }
      }

      // check if there is full match of the word from just buying letters and if yes, display final Win message
      //I am not sure if this is needed, but we can just delete this for loop and if statement to easily get rid of this action.
	  boolean fullMatch = true;
	  for (int index = 0; index < secretWord.length() && fullMatch; index++){ //loops through all the characters of secretWord
         if (secretWord.charAt(index) != displayWord[index]){
			   fullMatch = false;
		   }
	   }	 
	  	 
	   if (fullMatch){
         displayFinalMessage(true);
		   finished = true;
      }
   }

   // user made a guess so check if it is the secret string and end the game
   public static void makeGuess(String userGuessStr) {
      if (userGuessStr.equals(secretWord)){
         displayFinalMessage(true);
      }
      else{
         displayFinalMessage(false);
      }
      finished = true;
   }

   // get a guess when no more letters can be bought
   private static void getFinalGuess(Scanner scan) {
      System.out.print("The word now looks like this: ");
      System.out.println(displayWord);
      System.out.print("You must make a final guess: ");
      String finalResponse = scan.nextLine();
      finalResponse = finalResponse.toUpperCase();
      if (finalResponse.equals(secretWord)){ //checks if the guess is correct
         displayFinalMessage(true);
      }
      else{
         displayFinalMessage(false);
      }
      finished = true;
   }

   // Display the final result
   public static void displayFinalMessage(boolean success) {
      if (success) { // win
         System.out.println("You guessed the word: " + secretWord);
         System.out.printf("You win with a score of %d!\n", remainingChances);
      } else { // lost
         System.out.println("You lost!");
         System.out.printf("The word was: %s\n", secretWord);

      }
   }
}


