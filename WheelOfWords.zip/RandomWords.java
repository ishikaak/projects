//*******************************************************************
//      This program scans the word.txt file, puts the words in the
//       file into an array, and picks a random word from the array 
//       to be the secretWord in the Wheel of Words game.
//
//*******************************************************************
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class RandomWords {

	static int lineNumber = 0;
	static String[] words;
	static void readWordFile(){
		try {
			File file = new File("words.txt"); 
			Scanner scan = new Scanner(file); //scans words.txt
			lineNumber = 0;
			String line = "";
			while(scan.hasNextLine()){ //gets the total number of lines in the file
				line = scan.nextLine();
				lineNumber++;
			} 
			scan.close();
		} catch (FileNotFoundException e) { //returns an error if words.txt is not found
			System.out.println("Error: Unable to read file.");
		} // end of catch		
   }
   
	public static String pickAWord() {
		try {
		// stores the words in String[] array only once	
			if (lineNumber == 0) {
				readWordFile();
				words = new String[lineNumber]; //creates a String array for the file words
				File file = new File("words.txt"); 
				Scanner scan = new Scanner(file);
				for (int i = 0; i < lineNumber; i++){ //puts the words from the file in the array
					String word = scan.nextLine();
					words[i] = word;
				}
				scan.close();
			} // only need to read file once  
			String secretWord = words[(int) (Math.random() * lineNumber)];  //picks random word called secretWord
			return secretWord;
	  	} catch (Exception e) { //returns an error if there is no next line to go onto or no new word
			System.out.println("Error: No words found."); 
			return "";
	  	}
   	}  
} // end of class RandomWords