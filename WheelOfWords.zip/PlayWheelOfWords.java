//*******************************************************************
//      This program runs the Wheel of Words game by calling all the necessary methods.
//
//*******************************************************************
import java.util.Scanner;

public class PlayWheelOfWords {
   static final int MAXCHANCES = 8; //number of chances to make character guesses

   public static void main(String[] args) {
      String response;
      Scanner scan = new Scanner(System.in);

      do {
         // create the game for one round
         WheelOfWords.initialize(MAXCHANCES); //calls the method that picks the random secretWord

         WheelOfWords.play(scan); //calls the method that starts the game

         System.out.println();

         System.out.print("Play another round of Wheel of Words (y/n)?"); //asks player if they want to play again
         response = scan.nextLine(); //gets user input

         System.out.println();

      } while (response.equals("y") || response.equals("Y")); // allows y or Y
      scan.close();
   }
}
